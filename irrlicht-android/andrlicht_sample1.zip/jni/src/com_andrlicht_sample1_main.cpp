#include "com_andrlicht_sample1_main.h"
#include <irrlicht.h>

irr::IrrlichtDevice *pDevice;
irr::video::IVideoDriver *pVideo;
irr::scene::ISceneManager *pSmgr;
irr::gui::IGUIEnvironment *pGuiEnv;

void init()
{
	pDevice = irr::createDevice(					
		irr::video::EDT_OGLES1,
		irr::core::dimension2du(480,778)
		);

	pDevice->setWindowCaption(L"Type-A2");

	pVideo = pDevice->getVideoDriver();
	pSmgr = pDevice->getSceneManager();
	pGuiEnv = pDevice->getGUIEnvironment();

	pSmgr->addCameraSceneNode(0, irr::core::vector3df(0,0,-5), irr::core::vector3df(0,0,0));	

}

void update()
{
	static irr::u32 uLastTick=0;
	//�и������尪���
	irr::u32 uTick = pDevice->getTimer()->getTime();						
	irr::f32 fDelta = ((float)(uTick - uLastTick)) / 1000.f; //��Ÿ�� ���ϱ�
	uLastTick = uTick;
	
	irr::video::S3DVertex Vertices[4];
	irr::u16 Indice[6];

	Vertices[0] = irr::video::S3DVertex(-.5,-.5,0, 0,0,-1,irr::video::SColor(0,0,255,255),0,1);
	Vertices[1] = irr::video::S3DVertex(-.5,.5,0, 0,0,-1,irr::video::SColor(0,255,0,255),0,0);
	Vertices[2] = irr::video::S3DVertex(.5,.5,0, 0,0,-1,irr::video::SColor(0,255,255,0),1,0);
	Vertices[3] = irr::video::S3DVertex(.5,-.5,0, 0,0,-1,irr::video::SColor(0,0,255,0),1,1);

	Indice[0] = 0;
	Indice[1] = 1;
	Indice[2] = 2;
	Indice[3] = 3;
	Indice[4] = 0;
	Indice[5] = 2;
	
	pVideo->beginScene(true, true, irr::video::SColor(255,100,101,140));

	pSmgr->drawAll();
	pGuiEnv->drawAll();

	//���� �׸���
	{
		irr::core::matrix4 mat;//������ķ��ʱ�ȭ
		mat.makeIdentity();
		pVideo->setTransform(irr::video::ETS_WORLD, mat); //��ȯ�ʱ�ȭ

		irr::video::SMaterial m;
		m.Lighting = false;  //����Ʈ������ ���� �����γ��´�.
		//m.ZBuffer = false;

		pVideo->setMaterial(m);	
	}

	pVideo->drawIndexedTriangleList(
		Vertices,
		4,
		Indice,
		2
		);				

	pVideo->endScene();	
}

void resize(int w,int h)
{
	irr::core::dimension2du size(w,h);
	pVideo->OnResize(size);
}

#ifdef __cplusplus
extern "C" {
#endif
/*
 * Class:     com_andrlicht_sample1_main
 * Method:    nativeInit
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_com_andrlicht_sample1_main_nativeInit
  (JNIEnv *env, jobject obj)
  {
  	init();
  }

/*
 * Class:     com_andrlicht_sample1_main
 * Method:    nativeSetResDirectory
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_com_andrlicht_sample1_main_nativeSetResDirectory
  (JNIEnv *env, jobject obj, jstring str)
  {
  }

/*
 * Class:     com_andrlicht_sample1_main
 * Method:    nativeResize
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_com_andrlicht_sample1_main_nativeResize
  (JNIEnv *env, jobject obj, jint w, jint h)
  {
  	resize(w,h);
  }

/*
 * Class:     com_andrlicht_sample1_main
 * Method:    nativeOnEvent
 * Signature: (Lcom/andrlicht/sample1/irrEvent;)V
 */
JNIEXPORT void JNICALL Java_com_andrlicht_sample1_main_nativeOnEvent
  (JNIEnv *env, jobject obj1, jobject obj2)
  {
  }

/*
 * Class:     com_andrlicht_sample1_main
 * Method:    nativeUpdate
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_com_andrlicht_sample1_main_nativeUpdate
  (JNIEnv *env, jobject obj)
  {
  	update();
  }

#ifdef __cplusplus
}
#endif

