package com.andrlicht.sample1;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.MotionEvent;

public class main extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new irrlichtGLview(this));
    }
    
    static {
        System.loadLibrary("andrlicht_sample1");  // �߰�
    }

    
    public native void nativeInit();
    public native void nativeSetResDirectory(String path);
    public native void nativeResize(int width, int height);
    public native void nativeOnEvent(irrEvent event);
    public native void nativeUpdate();
}

class irrlichtGLview extends GLSurfaceView {
	private main m_ac;

	public irrlichtGLview(main ac){
		super(ac);
		m_ac = ac;
		setRenderer(new irrlichtRenderer(m_ac));
	}
	
	public boolean onTouchEvent(final MotionEvent event){
		return true;
	}
}

class irrlichtRenderer implements GLSurfaceView.Renderer {
	private main m_ac; 
	public irrlichtRenderer(main ac){
		m_ac = ac;
	}
	
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		m_ac.nativeInit();
	}
	
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		m_ac.nativeResize(width, height);
		
	}
	public void onDrawFrame(GL10 gl) {
		m_ac.nativeUpdate();
		
	}
}