package com.andrlicht.sample1;

public class irrEvent {
	public int m_Action;
	public float m_PosX;
	public float m_PosY;	

}
